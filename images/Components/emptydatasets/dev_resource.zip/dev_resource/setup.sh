#!/bin/bash

skip_live=$1

############################################## DEV SETUP #####################################################


RESOURCE_DIR="$(pwd)"

if [ -z "$skip_live" ]
then
read -p "Skip Live Server setup(yes/no)(if yes will setup builder server alone in C5 mode): " skip_live
echo Note: ALternatively setup.sh can be run like:   setup.sh yes  -to skip live server setup
fi

. $RESOURCE_DIR/script/function_util.sh

build_path=$(cut -d "=" -f2 <<< $(grep Current_Build_Url version.txt))/
echo BUILD URL:  $build_path

liveBuildHome="$PWD"'/AdventNetLive/Sas/'
BuilderBuildHome="$PWD"'/AdventNetBuilder/Sas/'

if [[ $skip_live != 'yes' &&  $skip_live != 'y' ]]
then
downloadLiveZip $build_path
fi

downloadBuilderZip $build_path

extractWars $BuilderBuildHome

extractMIWar $BuilderBuildHome $RESOURCE_DIR

downloadStaticZip $build_path $BuilderBuildHome

read -p "Enter db username : " db_username
read -p "Enter db password : " db_passwd
read -p "Enter server name : " server_name





./common_setup.sh $skip_live devsetup $RESOURCE_DIR $BuilderBuildHome $liveBuildHome $server_name $db_username $db_passwd


