#$Id$

# Change the value to POSTGRES / MYSQL depending on the type used
DBTYPE=MYSQL

clear
rm -vrf ../server/default/log/*
rm -vrf ../server/default/farm/*
rm -rf ../applications/extracted/*
rm -fv nohup.out

export host=localhost
export mysql="mysql -h $host -u root --password=changeit"
# PG Config..
export PGUSER=changeit
export PGPASSWORD=changeit
export psql="psql -U $PGUSER -h $host sasdb -q"

dropDatabases()
{
	dbPattern=$1
	list=`echo "show databases like '$dbPattern'" | $mysql| grep -v Database`
	for db in $list
	do
		echo "dropped $db"
		echo "set foreign_key_checks=0; drop database $db"| $mysql
	done
}
dropSchemas()
{
	dbPattern=$1
	availableSchemas=(`echo "select distinct(schemaname) from pg_tables where schemaname like '$dbPattern'" | $psql -t`)
	for i in ${availableSchemas[@]} ;
	do
		echo "drop schema $i cascade;" | $psql
	done
}

if [ "$DBTYPE" == "MYSQL" ]; then
	dropDatabases "%db"
	echo "create database jbossdb "|$mysql
else
	dropSchemas "%db"
	echo "drop schema jbossdb;CREATE SCHEMA jbossdb authorization $PGUSER;" | $psql -t
fi

sh Clear.sh

