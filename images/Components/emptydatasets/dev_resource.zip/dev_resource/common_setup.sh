#!/bin/bash

################################################### Common Actions #########################################################

skip_live=$1
zide_setup=$2
RESOURCE_DIR=$3
BuilderBuildHome=$4
liveBuildHome=$5
server_name=$6
db_username=$7
db_passwd=$8



. $RESOURCE_DIR/script/function_util.sh

#Create monitoring jbossdb
if [ ! -z $db_passwd ]
then
	mysql -Au root -p$db_passwd -Bse "CREATE DATABASE IF NOT EXISTS jbossdb;"
	mysql -Au root -p$db_passwd -Bse "CREATE DATABASE IF NOT EXISTS mi_jbossdb;"

else
	mysql -Au root -Bse "CREATE DATABASE IF NOT EXISTS jbossdb;"
	mysql -Au root -Bse "CREATE DATABASE IF NOT EXISTS mi_jbossdb;"
fi



################################################ Live setup ##########################################################

if [[ $skip_live != 'yes' &&  $skip_live != 'y' ]]
then

  disableLogs $liveBuildHome

  extractWars $liveBuildHome

  copyLiveFiles $RESOURCE_DIR $liveBuildHome

  copyConfigFiles $RESOURCE_DIR $liveBuildHome "false"

  setDBConfig $liveBuildHome $db_username $db_passwd

  replaceValues $server_name $liveBuildHome'tomcat/webapps/ROOT/' "false"

  upgradeSnappy $liveBuildHome

  updateSASKeyStore $liveBuildHome
fi


############################################### Builder setup #########################################################

#Disable tomcat logs
disableLogs $BuilderBuildHome


copyBuilderFiles $RESOURCE_DIR $BuilderBuildHome

copyConfigFiles $RESOURCE_DIR $BuilderBuildHome "true"

setDBConfig $BuilderBuildHome $db_username $db_passwd

replaceValues $server_name $BuilderBuildHome'tomcat/webapps/ROOT/' "true"

upgradeSnappy $BuilderBuildHome

updateSASKeyStore $BuilderBuildHome

setupMonitoring $RESOURCE_DIR $db_passwd

replaceMiMysqlConnector $BuilderBuildHome

replaceZohoInstrumentationJar $BuilderBuildHome


if [[ zide_setup != "zide" ]]
then
  downloadJar $RESOURCE_DIR
else
  downloadJar $RESOURCE_DIR'../'
fi

setServerNameInCaddy $RESOURCE_DIR $server_name

switchC5 $BuilderBuildHome

devSetupChanges $RESOURCE_DIR

echo "Build Setup Completed"