#!/bin/bash
#Script to setup and start dependency services caddy, cassandra, redis, MI and Kafka
export RESOURCE_DIR="$(pwd)"
export HOME_DIR="$(pwd)"
if [ ! -d "script" ]
then 
	export RESOURCE_DIR=$RESOURCE_DIR'/dev_resource'
fi
cd $RESOURCE_DIR
. script/caddy/setup_caddy.sh $HOME_DIR
cd $RESOURCE_DIR 
. script/setup_cassandra.sh $HOME_DIR
cd $RESOURCE_DIR 
. script/setup_redis.sh $HOME_DIR
#cd $RESOURCE_DIR
#. script/setup_kafka.sh $HOME_DIR
#cd $RESOURCE_DIR
#. script/monitor/setup_monitoring.sh $HOME_DIR

