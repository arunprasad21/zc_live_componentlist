#!/bin/bash

export RESOURCE_DIR="$(pwd)"
##################################BUILD SETUP SCRIPT START############################################### 

. setup_platform.sh

##################################BUILD SETUP SCRIPT END###############################################

echo "Starting Bookings setup"

sed -ie 's/value="300/value="30000/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/Persistence/persistence-configurations.xml
sed -ie 's/value="300/value="30000/g' $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/Persistence/persistence-configurations.xml

echo "Bookings Setup completed"
