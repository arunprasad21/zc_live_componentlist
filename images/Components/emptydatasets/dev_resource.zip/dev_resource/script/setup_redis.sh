#!/bin/bash
cd $1
startRedis()
{
	cd redis 
	if [  ! -z "$(ps aux | grep -v grep | grep redis-server | awk '{print $2}')" ]
	then
		export PID="$(ps aux | grep -v grep | grep redis-server | awk '{print $2}')"
		 kill -9 $PID
	fi
	  ./redis-server redis.conf >> redis-server-log.txt &
	sleep 1
	while ! grep -m1 'Ready to accept connections' < redis-server-log.txt; do
	    sleep 1
	done
	echo "Redis Server started localhost:6379"
}
if [ ! -d "redis" ]
then
	if [ $(uname -s) = 'Darwin' ]
	then
		FILE_NAME=redis-6.2.5-mac.tar
	else 
		FILE_NAME=redis-6.2.5-linux.tar
	fi
	curl -O 'http://creator-centos-2/redis/'$FILE_NAME
	tar -xvf $FILE_NAME
	rm $FILE_NAME
	startRedis
else
	if [  -z "$(ps aux | grep -v grep | grep redis-server | awk '{print $2}')" ]
	then
		startRedis
	else 
		echo "Redis server is already running localhost:6379"
	fi
fi