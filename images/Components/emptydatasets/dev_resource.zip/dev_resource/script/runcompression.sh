#!/bin/bash

#Usage : 
#sh compression.sh Path-to/AdventNetBuilder Path-to/AdventNetLive
#Restart builder and live servers after compression
 
CURRENT_DIR="$(pwd)"
builderBuildHome=$1
liveBuildHome=$2
webappsDir=$1'/Sas/tomcat/webapps'
libDir=$1'/Sas/tomcat/webapps/ROOT/WEB-INF/lib'
configDir=$1'/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator'
creatorDir=$webappsDir'/ROOT/creator'
cd $creatorDir
buildLabel=6834532
echo "Copying builder files"
ln -s $webappsDir'/ROOT' $webappsDir'/zohocreator'
echo "Copying live files"
ln -s $liveBuildHome'/Sas/tomcat/webapps/ROOT' $webappsDir'/appcreator'
cd $libDir
jar xf AdventNetAppCreator.jar com/adventnet/appcreator/compression/CompressFiles.class 
tomcatLib=$builderBuildHome/Sas/tomcat/lib
# If there's an error in the below line while running the script, check if the jar files mentioned here are present in the build.. 
export CLASSPATH=$CLASSPATH:"$CURRENT_DIR/../lib/closure-compiler.jar:$libDir/AdventNetAppCreator.jar:$libDir/yuicompressor-2.3.4.jar:$libDir/cssparser-0.9.27.jar:$libDir/xml-apis.jar:$tomcatLib/*:$libDir/zoho-security.jar:$libDir/json.jar:$libDir/xercesImpl.jar:$libDir/tika-core.jar:$libDir/xml-apis-ext.jar:$libDir/commons-codec-1.7.jar"
echo "Compression started"
java com/adventnet/appcreator/compression/CompressFiles $buildLabel $webappsDir $configDir $libDir "false"
java com/zoho/creator/compression/ClosureCompression $buildLabel $configDir $webappsDir  $libDir "false"
OUT=$?
if [ $OUT -eq 0 ]
	then 
			cp -r $webappsDir'/creator/'$buildLabel $webappsDir'/ROOT/creator'
			cp -r $webappsDir'/creator/'$buildLabel $liveBuildHome'/Sas/tomcat/webapps/ROOT/creator'
			echo "Enabling compression in live and builder servers"
			zc_prop=$builderBuildHome'/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties'
			sed -ie "s/^enableCompression=.*/enableCompression=true/g" $zc_prop
			zc_prop=$liveBuildHome'/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties'
			sed -ie "s/^enableCompression=.*/enableCompression=true/g" $zc_prop
			echo "Compression completed"
	else
			echo "Compression failed"
fi 
echo "Removing temporary files and directories"
rm -r -f $webappsDir'/creator'
rm -r -f $webappsDir'/temp'
rm -r -f $webappsDir'/appcreator'
rm -r -f $webappsDir'/zohocreator'
rm -r -f $libDir'/com'
