#!/bin/bash
setupCassandra3x(){
	echo "Setting up Cassandra 3.0.15"
	if [ ! -z "$(jps | grep CassandraDaemon)" ]
  	then
  	  export PID="$(jps | grep CassandraDaemon | awk '{print $1}')"
  		kill -9 $PID
  	fi
  cd $RESOURCE_DIR/cassandra
	if [ $processor = 'arm64' ]
	then
		downloadCassandraForM1
	else
		downloadCassandraForLinuxOrMac
	fi
	sed -ie "s~/var/lib/cassandra/data~$RESOURCE_DIR/cassandra/cassandraData/data~g" $CASS_HOME_3/conf/cassandra.yaml
	sed -ie "s~/var/lib/cassandra/commitlog~$RESOURCE_DIR/cassandra/cassandraData/commitlog~g" $CASS_HOME_3/conf/cassandra.yaml
	sed -ie "s~/var/lib/cassandra/saved_caches~$RESOURCE_DIR/cassandra/cassandraData/saved_caches~g" $CASS_HOME_3/conf/cassandra.yaml
	sed -ie "s~/var/lib/cassandra/hints~$RESOURCE_DIR/cassandra/cassandraData/hints~g" $CASS_HOME_3/conf/cassandra.yaml
	sed -ie "s~/home/sas~$CASS_HOME_3~g" $CASS_HOME_3/conf/logback.xml
	sleep 10
  	startCassandra3x
	sleep 10
	cd $RESOURCE_DIR/cassandra/
  sh $CASS_HOME_3/bin/nodetool upgradesstables
	sleep 5
}
startCassandra3x(){
	cd $RESOURCE_DIR

	# Check if a Mac machine
  if [ "$processor" = "arm64" ] || [ "$processor" = "i386" ]; then
      # Check if cassandra-jdk file exists
      if [ ! -d "cassandra-jdk" ]; then
          createDedicatedJDKForMac
      fi
      cd $RESOURCE_DIR
      # Set JAVA_HOME in cassandra.in.sh
      sed -ie "s~#JAVA_HOME=/usr/local/jdk6~JAVA_HOME=$(pwd)/cassandra-jdk/zulu8.62.0.19-ca-jdk8.0.332-macosx_x64/zulu-8.jdk/Contents/Home/~g" $CASS_HOME_3/bin/cassandra.in.sh
  fi
  # Check if processor is x86_64 Linux
  if [ "$processor" = "x86_64" ]; then
       # Check if cassandra-jdk file exists
       if [ ! -d "cassandra-jdk" ]; then
          createDedicatedJDKForLinux
       fi
       cd $RESOURCE_DIR
       # Set JAVA_HOME in cassandra.in.sh
       sed -ie "s~#JAVA_HOME=/usr/local/jdk6~JAVA_HOME=$(pwd)/cassandra-jdk/zulu8.62.0.19-ca-jdk8.0.332-linux_x64~g" $CASS_HOME_3/bin/cassandra.in.sh
  fi

	cd $CASS_HOME_3/bin
	sh cassandra >> cassandra-server-log.txt
	sleep 1
	while ! grep -m1 '127.0.0.1 state jump to NORMAL' < cassandra-server-log.txt; do
	    sleep 1
	done
	sleep 5
	if [ -z "$(jps | grep CassandraDaemon)" ]
    	then
    		startCassandra3x
    	else
    		echo "Cassandra server started successfully"
	fi
}
setupCassandra(){
  mkdir $RESOURCE_DIR/cassandra
	setupCassandra3x
}
downloadCassandraForM1(){
	echo "Downloading Cassandra for M1 ARM64."
	cd $RESOURCE_DIR/cassandra
	curl -O http://creator-centos-2/cassandra/creator-cassandra-3.0.15.tar.gz
	tar -zxvf creator-cassandra-3.0.15.tar.gz
	rm creator-cassandra-3.0.15.tar.gz
}
downloadCassandraForLinuxOrMac(){
	echo "Downloading Cassandra for Linux or Intel Mac."
	cd $RESOURCE_DIR/cassandra
	curl -O http://creator-centos-2/cassandra/apache-cassandra-3.0.15-bin.tar.gz
	tar -zxvf apache-cassandra-3.0.15-bin.tar.gz
	rm apache-cassandra-3.0.15-bin.tar.gz
}
createDedicatedJDKForM1(){
	echo "Creating dedicated JDK for M1."
	cd $RESOURCE_DIR
	mkdir cassandra-jdk
	cd cassandra-jdk
	curl -O http://creator-centos-2/jdk/jdk-11.0.14_osx-x64_bin.tar.gz
	tar -zxvf jdk-11.0.14_osx-x64_bin.tar.gz
	rm jdk-11.0.14_osx-x64_bin.tar.gz
}

createDedicatedJDKForLinux(){
	echo "Creating dedicated JDK for Linux."
	cd $RESOURCE_DIR
	mkdir cassandra-jdk
  cd cassandra-jdk
	curl -O http://creator-centos-2/jdk/zulu8.62.0.19-ca-jdk8.0.332-linux_x64.tar.gz
	tar -zxvf zulu8.62.0.19-ca-jdk8.0.332-linux_x64.tar.gz
	rm zulu8.62.0.19-ca-jdk8.0.332-linux_x64.tar.gz
}

createDedicatedJDKForMac(){
	echo "Creating dedicated JDK for Mac."
	cd $RESOURCE_DIR
	mkdir cassandra-jdk
  cd cassandra-jdk
	curl -O http://creator-centos-2/jdk/zulu8.62.0.19-ca-jdk8.0.332-macosx_x64.tar.gz
	tar -zxvf zulu8.62.0.19-ca-jdk8.0.332-macosx_x64.tar.gz
	rm zulu8.62.0.19-ca-jdk8.0.332-macosx_x64.tar.gz
}

RESOURCE_DIR="$(pwd)"
export CASS_HOME_3="$RESOURCE_DIR"'/cassandra/apache-cassandra-3.0.15'
export processor="$(arch)"

cd $RESOURCE_DIR
# Check if the cassandra folder exists
if [ ! -d "cassandra" ]; then
  # Call the setupCassandra method
  setupCassandra
else
  cd $RESOURCE_DIR/cassandra
  # Check if the apache-cassandra-3.0.15 folder exists inside cassandra
  if [ ! -d "apache-cassandra-3.0.15" ]; then
    # Call the startCassandra3x method
    setupCassandra3x
  else
    # Echo Cassandra server is already running
    if jps | grep -q CassandraDaemon; then
        echo "Cassandra server already running"
    else
        # Call the startCassandra method
        startCassandra3x
    fi
  fi
fi

