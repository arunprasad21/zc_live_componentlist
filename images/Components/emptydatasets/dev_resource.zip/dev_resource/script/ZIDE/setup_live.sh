#!/bin/bash

. $1/script/function_util.sh

setZIDE $1 $2 $3

