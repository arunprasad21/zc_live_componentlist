#!/bin/bash

. dev_resource/script/function_util.sh

db_username=`awk  -F"=" '/^db.username/{print $NF}' AdventNet/Sas/tomcat/webapps/ROOT/WEB-INF/conf/configuration.properties`
db_passwd=`awk  -F"=" '/^db.password/{print $NF}' AdventNet/Sas/tomcat/webapps/ROOT/WEB-INF/conf/configuration.properties`
			
setDBConfig AdventNetLive/Sas/ $db_username $db_passwd

echo "Live setup completed" 

