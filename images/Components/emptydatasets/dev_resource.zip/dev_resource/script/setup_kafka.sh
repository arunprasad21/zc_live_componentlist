#!/bin/bash
setupKafka(){
	mkdir apacheKafka
	cd apacheKafka
	curl -O http://creator-centos-2/apacheKafka/kafka.tar
	tar -xvf kafka.tar
	rm kafka.tar
	startKafka
	echo "Apache Kafka Setup Completed."
	
}
startKafka(){

	#Kill Zookeeper if running
	if [ ! -z "$(jps | grep QuorumPeerMain)" ]
	then
		export PID="$(jps | grep QuorumPeerMain | awk '{print $1}')"
		echo "Killing Zookeeper.."
		kill -9 $PID
	fi
	
	#Kill Kafka Broker if running
	if [ ! -z "$(jps | grep Kafka)" ]
	then
		export PID="$(jps | grep Kafka | awk '{print $1}')"
		echo "Killing Apache Kafka.."
		kill -9 $PID
	fi
	
	#Restart Zookeeper and Kafka
	cd $BUILD_HOME_DIR/apacheKafka/kafka_2.11-0.10.0.1
	echo "Starting Apache Zookeeper.."
	sh bin/zookeeper-server-start.sh config/zookeeper.properties > zookeeper.log &
	sleep 3
	
	echo "Starting Apache Kafka.."
	sh bin/kafka-server-start.sh config/server.properties > kafka.log &
	sleep 3
	
	if [ "$(jps | grep QuorumPeerMain)" -a "$(jps | grep Kafka)" ] 
	then
		echo "Apache Zookeeper and Kafka Started Successfully...."
	fi
}

BUILD_HOME_DIR="$(pwd)"
if [ ! -d "apacheKafka" ]
then
		setupKafka
else
		startKafka
fi

