#!/bin/bash

[ "$RESOURCE_DIR" == '' ] && export RESOURCE_DIR="$(pwd)"/..
. "$RESOURCE_DIR"/script/function_util.sh

NGINX_HOME=/usr/local/nginx
NGINX_BIN=$NGINX_HOME/sbin/nginx
NGINX_CONF=$NGINX_HOME/conf/nginx.conf

if [ "$(processcheck nginx)" == 'Running' ]
then
	sudo $NGINX_BIN -s reload
else
	sudo $NGINX_BIN
fi	

