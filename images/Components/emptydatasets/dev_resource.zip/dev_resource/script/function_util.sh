#!/bin/bash

processcheck () {
	
	ps_out=`ps -ef | grep $1 | grep -v 'grep' | grep -v $0`
	result=$(echo $ps_out | grep "$1")
	if [[ "$result" != "" ]]
	then
	    echo "Running"
	else
	    echo "Not Running"
	fi
	
}

getOS () {
	
	if [ $(uname -s) == 'Darwin' ]
	then
		echo "MAC"
	else
		echo "LINUX"
	fi	
}

disableLogs() {

	buildHome=$1
	echo "Disabling console logs... Logs can be found in ../logs/"
	echo "

	# File for container level log configuration. App specific log configuration can
	# be done inside <app>.war

	handlers = 1catalina.org.apache.juli.FileHandler

	.handlers = 1catalina.org.apache.juli.FileHandler

	1catalina.org.apache.juli.FileHandler.level = FINE
	1catalina.org.apache.juli.FileHandler.directory = ../logs/
	1catalina.org.apache.juli.FileHandler.prefix = catalina-
	" > $buildHome'tomcat/conf/logging.properties'
}

replaceValues() {

		builder_server=$3
		ROOT_dir=$2
		server_name=$1
		contextname=''
		
		resource_yml=$ROOT_dir'WEB-INF/conf/appcreator/resources-adminapi.yml'
		if [ "$builder_server" = true ]; then
		
			sed -ie "s/^api_server_url:.*/api_server_url: \"https:\/\/$server_name\"/g" $resource_yml
			
		fi
		
		zc_prop=$ROOT_dir'WEB-INF/conf/appcreator/zohocreator.properties'
		creator_public_server=$(echo $server_name | cut -d'.' -f 1)
		
		sed -ie "s/^creatorservername=.*/creatorservername=$server_name/g" $zc_prop
		sed -ie "s/^creatorliveserver=.*/creatorliveserver=$server_name:9000/g" $zc_prop
		sed -ie "s/^creatorpublicserverprefix=.*/creatorpublicserverprefix=$creator_public_server/g" $zc_prop
		sed -ie "s/^creatorlivepublicserverprefix=.*/creatorlivepublicserverprefix=$creator_public_server/g" $zc_prop
		#sed -ie "s/^creatornewlivepublicserverprefix=.*/creatornewlivepublicserverprefix=$creator_public_server/g" $zc_prop
        sed -ie "s/^creatorpublicserversuffix=.*/creatorpublicserversuffix=.csez.zohocorpin.com/g" $zc_prop
		sed -ie "s/^creatordomains=.*/creatordomains=.csez.zohocorpin.com/g" $zc_prop
		sed -ie 's/^integration.domain.name=.*/integration.domain.name=csez.zohocorpin.com/g' $zc_prop
		sed -ie 's/^sendMailServer=.*/sendMailServer=smtp/g' $zc_prop
		sed -ie 's@^iamurl=.*@iamurl=https://accounts.csez.zohocorpin.com/@g' $zc_prop
		sed -ie 's@^integrationTransmailUrl=.*@integrationTransmailUrl=https://internal1-transmail.localzoho.com@g' $zc_prop
		sed -ie 's@^mlAdminAccountZUID=.*@mlAdminAccountZUID=@g' $zc_prop
		sed -ie 's@^setup=.*@setup=dev@g' $zc_prop
		sed -ie 's/^globalSearchEnabled=.*/globalSearchEnabled=false/g' $zc_prop
    sed -ie 's/^enableCompression=.*/enableCompression=false/g' $zc_prop
    sed -ie 's/^useStaticServerForCompression=.*/useStaticServerForCompression=false/g' $zc_prop
		sed -ie 's@^timeZone=.*@timeZone=Asia/Kolkata@g' $zc_prop
		#sed -ie "s/^isCreator5Server=.*/isCreator5Server=true/g" $zc_prop
		echo "isPaymentTestingMode=false" >> $zc_prop
		echo "earrefreshtoken=1000.4a93274cca28f3f6bcb167f2fe8efef9.38fd62430144247ebb31703007018729" >> $zc_prop
		echo "#Machine Learning RELATED URLS, Committed by: Vignesh A (vignesh.a) -6692 Reason: Dev Setup ML Urls" >> $zc_prop
		echo "ZLabs_Auth_mode=ZCode" >> $zc_prop
		echo "mlauthenticationurl=https://accounts.localzoho.com" >> $zc_prop
		echo "zlabsmlurl=https://ml.zoho.com" >> $zc_prop
		echo "zlabsdlurl=https://dl.zoho.com" >> $zc_prop
		sed -ie "s/^enableCRMPush=.*/enableCRMPush=false/g" $zc_prop
		sed -ie "s/^enablePostMaster=.*/enablePostMaster=false/g" $zc_prop
		sed -ie "s/^enableUSCRMPush=.*/enableUSCRMPush=false/g" $zc_prop
		sed -ie "s/^enableInProductTip=.*/enableInProductTip=false/g" $zc_prop
		sed -ie "s/^enableUpgradeCampaigns=.*/enableUpgradeCampaigns=false/g" $zc_prop
		sed -ie "s/^enablePreSalesSupport=.*/enablePreSalesSupport=false/g" $zc_prop
		sed -ie "s/^enableMicsTracking=.*/enableMicsTracking=false/g" $zc_prop
		
		
		zc_dev_prop=$ROOT_dir'WEB-INF/conf/appcreator/zohocreator_dev.properties'
		echo "creatorexportserver="$server_name >> $zc_dev_prop
		echo "integrationGadgetsUrl="$server_name >> $zc_dev_prop
		echo "previewengineserverprefix=preview.csez.zohocorpin.com" >> $zc_dev_prop
		echo "creatorappdomainprefix="$server_name:9000 >> $zc_dev_prop
		echo "#Widgets(Sigma) related properties, Committed by: preethi-4967 Reason: Development Setup Widgets Config" >> $zc_dev_prop
    echo "integrationSigmaUrl=sigma.csez.zohocorpin.com" >> $zc_dev_prop
		echo "#Machine Learning related properties, Committed by: Vignesh A (vignesh.a) -6692 Reason: Dev Setup ML Configurations" >> $zc_dev_prop
		echo "ZLabs_ZCode_URL=http://creator-ml.zcodeusers.com/ZCMLOAuthGenerator" >> $zc_dev_prop
		echo "ZLabs_ZCode_key=18b142a966588d12f3337a973a6da8ddf1e56bc34245939f6b94ed9f8db17313" >> $zc_dev_prop
		
		cass_prop=$ROOT_dir'WEB-INF/conf/appcreator/cassandra.properties'
		sed -ie "s/cassandra.seednodes=.*/cassandra.seednodes=localhost/g" $cass_prop
		sed -ie "s/cassandra.localDC=.*/cassandra.localDC=DC1/g" $cass_prop
		
		wms_prop=$ROOT_dir'WEB-INF/conf/wmsapi.properties'
		sed -ie "s@routingserver=.*@routingserver=internal.wmsrouter.csez.zohocorpin.com:6060@g" $wms_prop

		log_prop=$ROOT_dir'WEB-INF/classes/logging.properties'
		sed -ie 's/^.level=SEVERE/.level=INFO/g' $log_prop
		sed -ie 's/^com.zoho.logs.config.local.logging=.*/com.zoho.logs.config.local.logging=true/g' $log_prop
		echo "com.adventnet.appcreator.util.FeatureTrackingFilter.level=OFF" >> $log_prop
	
		sec_pro=$ROOT_dir'WEB-INF/security-properties.xml'
		sed -ie 's/^.*com.adventnet.iam.internal.server.*/<property name=\"com.adventnet.iam.internal.server\" value=\"https:\/\/accounts.csez.zohocorpin.com\"\/>/g' $sec_pro
		sed -ie 's/^.*antivirus.host.*//g' $sec_pro
		sed -ie 's/^.*antivirus.port.*//g' $sec_pro

		zcl_conf_prop=$ROOT_dir'WEB-INF/conf/ZCL/zcl-config.properties'
		sed -ie 's/^captureStackTraceForResource=.*/captureStackTraceForResource=true/g' $zcl_conf_prop
		sed -ie 's/^throwResourceLeakException=.*/throwResourceLeakException=true/g' $zcl_conf_prop

		appcreator_zcl_queue_prop=$ROOT_dir'WEB-INF/conf/appcreator/zcl-queue.properties'
		sed -ie 's/^creator-zlquery.*/#creator-zlquery/g' $appcreator_zcl_queue_prop
	
		zfs_pro=$ROOT_dir'WEB-INF/conf/zfsserver.properties'
		sed -ie 's/^com.zoho.zfs.server.url=.*/com.zoho.zfs.server.url=https:\/\/zfs.csez.zohocorpin.com\/zfs/g' $zfs_pro
		sed -ie 's/^com.zoho.zfs.internal.server.url=.*/com.zoho.zfs.internal.server.url=https:\/\/zfs.csez.zohocorpin.com\/zfs/g' $zfs_pro
		sed -ie "s/^com.zoho.zfs.ear.allied_services=.*/com.zoho.zfs.ear.allied_services=creator/g" $zfs_pro

		zfs_ear_pro=$ROOT_dir'WEB-INF/conf/zfsear.properties'
		echo "\nzfsear.creator.kmstoken=1000.4a93274cca28f3f6bcb167f2fe8efef9.38fd62430144247ebb31703007018729" >> $zfs_ear_pro

		zpe_pro=$ROOT_dir'WEB-INF/conf/zpeclient.properties'
		sed -ie 's/^bootstrap.servers=.*/bootstrap.servers=docs-centos7-2:9092/g' $zpe_pro
				
		security_privatekey=$ROOT_dir'WEB-INF/conf/security-privatekey.xml'
		echo "<security><properties><property name='internalrequest.privatekey' value='30820153020100300d06092a864886f70d01010105000482013d3082013902010002410095292ae664d2ced76637168e63230be11b68c07b2e1a5a904d526c086973245f7f1e044af03fa831b10baac2d42cac41d0a388b5aa115d3067be5eb17fd951830203010001024054609a5d0471e0022757485239b06c9ae5976733074c6f28ac24d0ea1d44be30cdfd956eb61afaf174253e9ffefaed742919413a88b78ac58babc21b187d68a1022100cbf90a01199cb7214cc2b67d8697944b82218eb30b1211ae215fce85eb5c5e13022100bb3507927a794109c4d9c7d01153cb4c877e875257d4ac0ee09fea9a5d4decd102203907c4b85204f35f282b390317e2c1dfeade9f1b8878e0e0a30c3a9e4f14606902205cef086148f764b80ac6ea107a6994a4db268edaebcb21d708df9a41234c89e1022047457d58b90a9f75878eb02aedd0c305e367c95cb7395fc9f2c6826219b37cd3'/></properties></security>" > $security_privatekey
	
		conf_prop=$ROOT_dir'WEB-INF/conf/configuration.properties'
		#sed -ie "s/^com.zoho.instrument=.*/com.zoho.instrument=false/g" $conf_prop
		sed -ie 's/^db.use.redis.for.sasthreadlocal=.*/db.use.redis.for.sasthreadlocal=false/g' $conf_prop
		echo 'DFS.GRIDIDS=NN902' >> $conf_prop
		echo 'DFS.WRITABLE_GRID=true' >> $conf_prop
		echo 'DFS.NN902=172.20.20.57:54310' >> $conf_prop
		echo 'DFS.NN902.WRITABLE=true' >> $conf_prop

		transmail_config=$ROOT_dir'WEB-INF/conf/transmail-config.properties'
		echo "\ntransmail.client.secret=686fb9f781b125aa75abf9285b8b196665873114e5" >> $transmail_config
		echo "transmail.iam.host.url=https://accounts.localzoho.com" >> $transmail_config
		echo "transmail.client.id=1003.OAH7V2P3I2LMVIV5E0I5T0JW2YZGCE" >> $transmail_config
		echo "transmail.internal.refresh.token=1003.3a8fbd72ab623663bbffb1e6b015aea8.6ab3d6c1e5210833e5ab00d2889a4a75" >> $transmail_config		
		echo "transmail.apple.refresh.token=1003.1442184feaeb026e02a3036c2919d8d0.2821f1efe6af5521fc307ec9aab5efbd" >> $transmail_config

		sed -ie 's/^sas.\(dbserver\).cluster=.*/sas.\1.cluster=127.0.0.1/g' $conf_prop
		sed -ie 's/^sas.\(dbserver\).master=.*/sas.\1.master=16.3.1.10/g' $conf_prop
		sed -ie 's/^sas.\(dbserver\).slave=.*/sas.\1.slave=16.3.1.11/g' $conf_prop
		
		sed -ie 's/^sas.\(backupserver\).cluster=.*/sas.\1.cluster=127.0.0.1/g' $conf_prop
		sed -ie 's/^sas.\(backupserver\).master=.*/sas.\1.master=16.3.1.10/g' $conf_prop
		sed -ie 's/^sas.\(backupserver\).slave=.*/sas.\1.slave=16.3.1.11/g' $conf_prop
		
		sed -ie 's/production=.*/production=false/g' $conf_prop
		sed -ie "s@app.home=.*@app.home=$2/WEB-INF@g" $conf_prop
		sed -ie "s@app.context=.*@app.context=$contextname@g" $conf_prop

		sed -ie "s/^sas.grid.transposerip=.*/sas.grid.transposerip=0.31.0.0/g" $conf_prop
		sed -ie "s/^cache.tenurespace=.*/cache.tenurespace=false/g" $conf_prop
		sed -ie "s/^com.adventnet.sas.nomanagedconnections.restart=.*/com.adventnet.sas.nomanagedconnections.restart=false/g" $conf_prop
		sed -ie "s/^db.nonpropagated.modules=.*/db.nonpropagated.modules=WorkEngine,Deluge,appcreator,appcreatorgen,platform/g" $conf_prop
		sed -ie "s/^com.zoho.sas.db.tracing.threshold=.*/com.zoho.sas.db.tracing.threshold=60000/g" $conf_prop

		sed -ie "s/^com.zoho.sas.db.tracing=.*/com.zoho.sas.db.tracing=false/g" $conf_prop
		sed -ie "s/^db.ukmodules=.*/db.ukmodules=appcreatorgen,Scheduler/g" $conf_prop
		sed -ie "s/^db.url=.*/db.url=jdbc:mysql:\/\/\$host:\$port\/\$dbName\?useUnicode=true\&characterEncoding=UTF-8\&tcpKeepAlive=true\&zeroDateTimeBehavior=convertToNull\&useOldAliasMetadataBehavior=true/g" $conf_prop

    cat $RESOURCE_DIR'/change_files/configuration_dev.properties' >> $ROOT_dir'WEB-INF/conf/configuration.properties'

		provisioning_conf_xml=$ROOT_dir'WEB-INF/conf/SAS/provisioning-configuration.xml'
        sed -ie "s@<GridConfiguration propname=\"redis-server-ip\" propval=\"default\"/>@<GridConfiguration propname=\"redis-server-ip\" propval=\"localhost\"/>@g" $provisioning_conf_xml
        sed -ie "s@<GridConfiguration propname=\"redis-server-port\" propval=\"default\"/>@<GridConfiguration propname=\"redis-server-port\" propval=\"6379\"/>@g" $provisioning_conf_xml
        
        
 
		web_xml=$ROOT_dir'WEB-INF/web.xml'
		sed -ie 's@security.xml@security.xml,security-proxies.xml@g' $web_xml
    	sed -ie 's@security-extension.xml@security-extension.xml,security-prism.xml@g' $web_xml

		stratus_props=$ROOT_dir'WEB-INF/conf/Stratus/stratus.properties'
		sed -ie "s/^TEST_MODE=.*/#For REST api related testing, Update TEST_MODE value to false\nTEST_MODE=true/g" $stratus_props
		sed -ie "s/^EAR_TOKEN=.*/EAR_TOKEN=1000.4a93274cca28f3f6bcb167f2fe8efef9.38fd62430144247ebb31703007018729/g" $stratus_props
		sed -ie "s/^DELETED_FILES_RETENTION_PERIOD=.*/DELETED_FILES_RETENTION_PERIOD=0/g" $stratus_props
		sed -ie "s/^CLIENT_SECRET_KEY=.*/CLIENT_SECRET_KEY=d3dd556bde48fa7e4ed73a0d761334cf1d61ecef65746bb4a437fac608104ec3/g" $stratus_props

		app_web_xml=$ROOT_dir'WEB-INF/web.xml'
    	sed -ie "/<!-- UNCOMMENT THE SERVLET TO ENABLE DYNAMIC JSP COMPILATION/d" $app_web_xml
    	sed -ie "/UNCOMMENT THE SERVLET TO ENABLE DYNAMIC JSP COMPILATION -->/d" $app_web_xml
		 
		if [ "$builder_server" = true ]; then
		 
		 	struts_xml=$ROOT_dir'WEB-INF/classes/struts.xml'
			#sed -ie "s|struts-appbuilder-4.xml|struts-appbuilder-5.xml|" $struts_xml
			
			web_xml=$ROOT_dir'WEB-INF/web.xml'
			#sed -ie "s|tiles-appbuilder-4.xml|tiles-appbuilder-5.xml|" $web_xml

			builder_security_platform_xml=$ROOT_dir'WEB-INF/security-platform.xml'
			sed -ie 's@<!--<url path="/platform/iam.jsp.*@<url path="/platform/iam.jsp" trusted="true" operation-type="write"/>@g'  $builder_security_platform_xml
			
			#builder_struts_properties=$ROOT_dir'WEB-INF/classes/struts.properties'
			#sed -ie "s/struts.devMode=.*/struts.devMode=true/g" $builder_struts_properties

			builder_rewrite_conf=$ROOT_dir'WEB-INF/rewrite.config'
			sed -ie "s|developer.zoho.com|developer.csez.zohocorpin.com|" $builder_rewrite_conf
			sed -ie "s|#CREATOR_CONTEXT|RewriteRule ^/(creator\|fonts\|_wms)/(.*)$ - [L]|" $builder_rewrite_conf

			security_static_xml=$ROOT_dir'WEB-INF/security-static.xml'
			echo '<?xml version="1.0" encoding="UTF-8"?><security name="Creator Static" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><urls xframe-type="deny">        <url path="/.*\.jpg" path-regex="true" content-type-options="false" dynamic-params="true"/>        <url path="/.*\.gif" path-regex="true"  content-type-options="false" dynamic-params="true"/>        <url path="/.*\.ico" path-regex="true"  content-type-options="false" dynamic-params="true"/>        <url path="/.*\.css" path-regex="true" content-type-options="false" dynamic-params="true"/>		<url path="/.*\.js" path-regex="true" content-type-options="false" dynamic-params="true"/>		<url path="/.*\.eot" path-regex="true" content-type-options="false" dynamic-params="true"/>		<url path="/.*\.svg" path-regex="true" content-type-options="false" dynamic-params="true"/>        <url path="/.*\.jp2" path-regex="true" content-type-options="false" dynamic-params="true"/>		<url path="/.*\.woff" path-regex="true" content-type-options="false" dynamic-params="true"/>        <url path="/.*\.woff2" path-regex="true" content-type-options="false" dynamic-params="true"/>        <url path="/.*\.otf" path-regex="true" content-type-options="false" dynamic-params="true"/>        <url path="/.*\.ttf" path-regex="true" content-type-options="false" dynamic-params="true"/></urls></security>' > $security_static_xml

			cp $ROOT_dir'app/common/images/flags.png' $ROOT_dir'app/form/images'
			cp $ROOT_dir'app/common/images/flags.png' $ROOT_dir'dashboard/images'
			builder_security_properties_xml=$ROOT_dir'WEB-INF/security-zohocreator-properties.xml'
			sed -ie "s/172.28.231.52/127.0.0.1/" $builder_security_properties_xml

			security_platform_xml_dir=$ROOT_dir'WEB-INF/security-platform.xml'
      		commentedLine='<!-- <url path=\"/platform/iam.jsp\" trusted=\"true\" operation-type=\"write\"/>-->'
      		unCommentedLine='<url path=\"/platform/iam.jsp\" trusted=\"true\" operation-type=\"write\"/>'

      		sed -ie "s|$commentedLine|$unCommentedLine|" $security_platform_xml_dir


#    		Uncomment to access admin tools
#     		security_admin_xml_dir=$ROOT_dir'WEB-INF/security-admin.xml'
#     		sed -ie "s/roles/checks/g" $security_admin_xml_dir




		else

			live_configuration_properties=$ROOT_dir'WEB-INF/conf/configuration.properties'
			echo "com.zoho.taskengine.client.enable=false" >> $live_configuration_properties

		fi
		rm $ROOT_dir'56CA532B2A0F8F55F2A87DD414860A7F.txt' $ROOT_dir'221BD786851DC7D9FCC2D287F1D73B5E.txt' $ROOT_dir'C8C4266A847F7AC0888DF84CC2A988E5.txt'

		precompileRemove $web_xml
}

copyConfigFiles() {

		dev_resource_dir=$1
		buildHome=$2
		builderServer=$3
		cd $2'tomcat/webapps/ROOT'
		
		cp $dev_resource_dir/change_files/cassandra-replication.xml $buildHome'tomcat/webapps/ROOT/WEB-INF/conf/appcreator/'
		
		port_conf='WEB-INF/conf/SAS/port-conf.xml'
			if [ $builderServer = true ]; then
				echo "<root><file original-file='conf/server.xml.orig' conf-file='conf/server.xml'><port default='8081' system-property='sas.http.port' /><port default='8444' system-property='sas.https.port' /></file></root>" > $port_conf
			else
				echo "<root><file original-file='conf/server.xml.orig' conf-file='conf/server.xml'><port default='8080' system-property='sas.http.port' /><port default='8443' system-property='sas.https.port' /></file></root>" > $port_conf
			fi
	
}

setDBConfig() {

		db_username=$2
		db_passwd=$3
	
		conf_prop=$1'/tomcat/webapps/ROOT/WEB-INF/conf/configuration.properties'
		mi_conf_prop=$1'/tomcat/webapps/mi/WEB-INF/conf/configuration.properties'
		sed -ie "s/^db.username=.*/db.username=$db_username/g" $conf_prop
		sed -ie "s/^db.password=.*/db.password=$db_passwd/g" $conf_prop
		sed -ie "s/^db.username=.*/db.username=$db_username/g" $mi_conf_prop
    sed -ie "s/^db.password=.*/db.password=$db_passwd/g" $mi_conf_prop

}

#setZIDE() {
#
#			RESOURCE_DIR=$1
#			liveBuildHome=$2
#			server_name=$3
#
#			copyLiveFiles $RESOURCE_DIR $liveBuildHome
#
#			#Disable tomcat logs
#			disableLogs "$liveBuildHome"
#
#			extractWars $liveBuildHome
#
#			copyConfigFiles $RESOURCE_DIR $liveBuildHome "false"
#
#			replaceValues $server_name $liveBuildHome'tomcat/webapps/ROOT/' "false"
#
#			setLiveRewriteValve $RESOURCE_DIR $liveBuildHome
#
#			replaceGridConf $liveBuildHome
#
#			cp $RESOURCE_DIR/change_files/instrument-configuration.xml $liveBuildHome/tomcat/webapps/ROOT/WEB-INF/conf/SAS/
#
#}

copyLiveFiles() {

		LiveBuildHome=$2
		dev_resource_dir=$1
		
		cp $dev_resource_dir'/change_files/bin/'* $LiveBuildHome'/bin'
		cp $dev_resource_dir'/change_files/tomcat/conf/server.xml' $LiveBuildHome'/tomcat/conf/server.xml'
		cp $dev_resource_dir'/change_files/security-proxies.xml' $LiveBuildHome'/tomcat/webapps/ROOT/WEB-INF/'
		cp $dev_resource_dir'/change_files/instrument-configuration.xml' $LiveBuildHome'/tomcat/webapps/ROOT/WEB-INF/conf/SAS/'

	  	replaceGridConf $LiveBuildHome
		
		live_server_xml=$LiveBuildHome'/tomcat/conf/server.xml'
		sed -ie "s/9080/8080/g" $live_server_xml	
		sed -ie "s/9443/8443/g" $live_server_xml


}


setupMonitoring(){
    resource_dir=$1
    db_passwd=$2
  	if [ ! -z $db_passwd ]
  	then
  		sed -ie "s/passwd=.*/passwd=-p$db_passwd/g" $resource_dir'/script/monitor/ipupdate.sh'
  	fi
}



downloadJar() {

	  resource_dir_lib=$1'/lib'


		mkdir $resource_dir_lib
		curl -O http://creator-centos-2/closure/closure-compiler-v20180910.jar
		mv closure-compiler-v*.jar $resource_dir_lib'/closure-compiler.jar'
}

replaceGridConf() {
		provisioning_conf_xml=$1'tomcat/webapps/ROOT/WEB-INF/conf/SAS/provisioning-configuration.xml'
        sed -ie "s@<GridConfiguration propname=\"monitoring-server-ip\" propval=\"default\"/>@<GridConfiguration propname=\"monitoring-server-ip\" propval=\"127.0.0.1\"/>@g" $provisioning_conf_xml
        sed -ie "s@<GridConfiguration propname=\"monitoring-server-ip-timeseries\" propval=\"default\"/>@<GridConfiguration propname=\"monitoring-server-ip-timeseries\" propval=\"127.0.0.1\"/>@g" $provisioning_conf_xml
 		sed -ie "s@<GridConfiguration propname=\"monitoring-server-port\" propval=\"default\"/>@<GridConfiguration propname=\"monitoring-server-port\" propval=\"34400\"/>@g" $provisioning_conf_xml
        sed -ie "s@<GridConfiguration propname=\"monitoring-server-port-timeseries\" propval=\"default\"/>@<GridConfiguration propname=\"monitoring-server-port-timeseries\" propval=\"34500\"/>@g" $provisioning_conf_xml		
}
 
copyBuilderFiles() {
		
		BuilderBuildHome=$2
		dev_resource_dir=$1

	 	cp $dev_resource_dir'/change_files/bin/'* $BuilderBuildHome/bin	
	 	cp $dev_resource_dir'/change_files/tomcat/conf/server.xml' $BuilderBuildHome/tomcat/conf/server.xml
	 	cp $dev_resource_dir'/change_files/security-proxies.xml' $BuilderBuildHome'/tomcat/webapps/ROOT/WEB-INF/' 
	 	cp $dev_resource_dir'/change_files/instrument-configuration.xml' $BuilderBuildHome'/tomcat/webapps/ROOT/WEB-INF/conf/SAS/'

    	replaceGridConf $BuilderBuildHome

	 	builder_server_xml=$BuilderBuildHome'/tomcat/conf/server.xml'
		sed -ie "s/8080/8081/g" $builder_server_xml	
		sed -ie "s/8443/8444/g" $builder_server_xml
		sed -ie "s/8009/8010/g" $builder_server_xml	
		sed -ie "s/8505/8506/g" $builder_server_xml	 


}

extractWars() {

		buildHome=$1
		unzip -qo $buildHome'tomcat/webapps/ROOT.war' -d $buildHome'tomcat/webapps/ROOT'
		rm -rf  $buildHome'tomcat/webapps/ROOT.war'
}

extractMIWar(){
   buildHome=$1
   dev_resource_dir=$2
   mv $dev_resource_dir'/mi.war' $buildHome'tomcat/webapps/'
   unzip -qo $1'tomcat/webapps/mi.war' -d $1'tomcat/webapps/mi'
   rm -rf  $buildHome'tomcat/webapps/mi.war'
}

precompileRemove() {
	
	web_xml=$1
	webapp_end="</web-app>"

	cp $web_xml temp.xml
	cat $web_xml | sed '/CREATOR WEB XML END/,$d' > temp.xml
	echo $webapp_end >> temp.xml
	mv temp.xml $web_xml
}


upgradeSnappy(){
   if [[ $(uname) == "Darwin" && $(uname -m) == "arm64" ]]; then

      lib_home=$1'tomcat/webapps/ROOT/WEB-INF/lib/'

      # Remove the older version of the Snappy Java library
      rm -f $lib_home'snappy-java-1.1.2.6.jar'

      # Download the Snappy Java library
       curl -O --output-dir $lib_home http://cm-server/thirdparty_downloads/Snappy/1_1_8_4/snappy-java-1.1.8.4.jar

  fi
}

setServerNameInCaddy(){
  RESOURCE_DIR=$1
  server_name=$2
  caddyFile=$RESOURCE_DIR'/change_files/caddy/Caddyfile'
  sed -ie "s/localhost/$server_name/g" $caddyFile
}

switchC5()
{
	build_home=$1'tomcat/webapps/ROOT/WEB-INF'
	zc_prop=$build_home'/conf/appcreator/zohocreator.properties'
	struts_prop=$build_home'/classes/struts.properties'

	sed -ie "s/^struts.custom.i18n.resources=.*/struts.custom.i18n.resources=MarketplaceResources,MessageResources,AppMessageResources,DelugeMessageResources,LiveMessageResources,BuilderMessages,HelpOnboardMessages,HomePage/g" $struts_prop

	sed -ie "s/^isCreator5Server=.*/isCreator5Server=true/g" $zc_prop

	struts_xml=$build_home'/classes/struts.xml'
	sed -ie "s/struts-appbuilder-4.xml/struts-appbuilder-5.xml/g" $struts_xml
	sed -ie "s/struts-userhome-4.xml/struts-userhome-5.xml/g" $struts_xml

	tiles_xml=$build_home'/web.xml'
	sed -ie "s/tiles-appbuilder-4.xml/tiles-appbuilder-5.xml/g" $tiles_xml
}


devSetupChanges(){
  RESOURCE_DIR=$1
  sed -ie "s/--password=changeit/--password=/g" $RESOURCE_DIR'/Reinit.sh'
}

downloadLiveZip(){

  build_path=$1

  rm AdventNetAppCreator_Live.zip
  curl -O $build_path'AdventNetAppCreator_Live.zip'
  unzip -d . "AdventNetAppCreator_Live.zip"
  rm AdventNetAppCreator_Live.zip
  rm -rf AdventNetLive
  mv AdventNet AdventNetLive

}

downloadBuilderZip(){

  build_path=$1

  rm AdventNetAppCreator_Builder.zip
  curl -O $build_path'AdventNetAppCreator_Builder.zip'
  unzip -d . "AdventNetAppCreator_Builder.zip"
  rm AdventNetAppCreator_Builder.zip
  rm -rf AdventNetBuildera
  mv AdventNet AdventNetBuilder

}

downloadStaticZip(){

  build_path=$1
  BuilderBuildHome=$2

  rm ZohoCreatorStatic.zip
  curl -O $build_path'ZohoCreatorStatic.zip'
  unzip -o -d ZohoCreatorStatic "ZohoCreatorStatic.zip"
  rm ZohoCreatorStatic.zip

  rm -rf $BuilderBuildHome'/tomcat/webapps/ROOT/creator'
  mv "$PWD"'/ZohoCreatorStatic' $BuilderBuildHome'/tomcat/webapps/ROOT/creator'
  rm -rf "$PWD"'/ZohoCreatorStatic'

}

updateSASKeyStore(){

  build_home=$1
  keystore_path=$build_home'tomcat/conf/sas.keystore'

  curl -o $keystore_path https://apptier.csez.zohocorpin.com/_static/keystore/2023-2024/sas.keystore

}

replaceMiMysqlConnector(){

  root_mysql_connector_jar_path=$1'tomcat/webapps/ROOT/WEB-INF/lib/mysql_connector.jar'
  mi_mysql_connector_jar_dir_path=$1'tomcat/webapps/mi/WEB-INF/lib'

  rm $mi_mysql_connector_jar_dir_path'/mysql-connector-java-5.1.44-bin.jar'

  cp $root_mysql_connector_jar_path $mi_mysql_connector_jar_dir_path

}

replaceZohoInstrumentationJar(){
  sas_lib_path=$1'lib/zohoinstrumentation.jar'
  curl -o $sas_lib_path http://creator-centos-2/zohoinstrumentation/zohoinstrumentation.jar
}