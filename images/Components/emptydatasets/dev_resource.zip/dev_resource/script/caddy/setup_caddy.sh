#!/bin/bash
RESOURCE_DIR="$(pwd)"
cd $1
if [ ! -d caddy ]; then
	if [ $(uname -s) = 'Darwin' ]; then
		if [ $(uname -m) = 'arm64' ]; then
			FILE_NAME=caddy_darwin_arm64_M1
		elif [ $(uname -m) = 'x86_64' ]; then
			FILE_NAME=caddy_darwin_amd64
		fi
	elif [ $(uname -s) = 'Linux' ]; then
	    FILE_NAME=caddy_linux_amd64
	fi
	mkdir caddy
	curl -o caddy/caddy_exe -O http://creator-centos-2/caddy/v2download/$FILE_NAME
	chmod 777 caddy/caddy_exe
	cp $RESOURCE_DIR'/change_files/caddy/Caddyfile' caddy/
	cp $RESOURCE_DIR'/script/caddy/start_caddy.sh' caddy/
fi
cd caddy
sudo ./start_caddy.sh
