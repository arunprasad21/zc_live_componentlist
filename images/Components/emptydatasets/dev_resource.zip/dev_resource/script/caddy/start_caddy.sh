#!/bin/bash
export CADDY="$(pwd)"/caddy_exe
sudo killall caddy_exe
sudo nohup $CADDY start