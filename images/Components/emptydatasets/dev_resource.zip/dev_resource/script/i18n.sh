#Usage : 
#sh i18n.sh Path-to/AdventNetBuilder 

builderHome=$1
buildLabel=6834532

WEBINFDir=$builderHome'/Sas/tomcat/webapps/ROOT/WEB-INF'
libDir=$WEBINFDir'/lib'
classesDir=$WEBINFDir'/classes'
readDir=$WEBINFDir'/conf'
writeDir=$builderHome'/Sas/tomcat/webapps/ROOT/'

export CLASSPATH=$CLASSPATH:"$libDir/zoho-security.jar:$libDir/AdventNetAppCreator.jar:$classesDir:$libDir/xml-apis.jar:$libDir/tika-core.jar:$libDir/commons-lang3-3.9.jar:$builderHome/../lib/closure-compiler.jar:$libDir/json.jar:$libDir/commons-codec-1.7.jar:$libDir/xercesImpl.jar:$libDir/../../../../lib/servlet-api.jar"

echo "-I18N JS FILES GENERATION STARTED- "
java com/zoho/creator/i18n/JsGenerator $writeDir $readDir $buildLabel
echo "-I18N JS FILES GENERATION COMPLETED-"
