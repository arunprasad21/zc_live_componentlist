#!/bin/bash
RESOURCE_DIR="$(pwd)"
cd $1
if [ ! -d "ZohoMonitoring" ]
then
	conf=/usr/local/mysql/my.cnf
	if [ -f "$conf" ]
	then
		if ( grep "STRICT_TRANS_TABLES" $conf )
		then
			sudo sed -ie "s/^sql_mode=.*/sql_mode=NO_ENGINE_SUBSTITUTION/g" $conf
			echo "Restarting mysql server..."
			sudo /usr/local/mysql/support-files/mysql.server restart
		fi 
	fi 
	curl -O 'http://creator-centos-2/zohomonitor/ZohoMonitoring.zip'
	unzip ZohoMonitoring.zip
	rm ZohoMonitoring.zip
	cd ZohoMonitoring/AdventNet/Sas/bin
	sed -ie $'/rm temp.properties/i\\
	\ \ \ \ sed -ie "s@db.url=.*@db.url=jdbc:mysql://\\\$host:\\\\$port/\\\\$dbName?useUnicode=true\\\\&characterEncoding=UTF-8\\\\&tcpKeepAlive=true\\\\&zeroDateTimeBehavior=convertToNull\\\\&useOldAliasMetadataBehavior=true@" WEB-INF/conf/configuration.properties\\
	\ \ \ \ sed -ie "s@sas.dbserver.cluster=.*@sas.dbserver.cluster=127.0.0.1@" WEB-INF/conf/configuration.properties\\
	\ \ \ \ sed -ie "s@sas.backupserver.cluster=.*@sas.backupserver.cluster=127.0.0.1@" WEB-INF/conf/configuration.properties
	' "runmonitoring.sh"
	
	cd RESOURCE_DIR
fi
cd ZohoMonitoring/AdventNet/Sas/bin
MPID="$(ps aux | grep -v grep | lsof -n -i:8082 | grep LISTEN | awk '{print $2}')" 
kill -9 $MPID
sh runmonitoring.sh
cd $RESOURCE_DIR'/script/monitor'
PID="$(ps aux | grep -v grep | grep ipupdate.sh | awk '{print $2}')"
if [ ! -z $PID ]
then
	kill -9 $PID
fi
nohup sh ipupdate.sh &
echo "Monitoring server started in port 8082"
