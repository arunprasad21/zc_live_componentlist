#!/bin/bash
#updates build IP in monitoring jbossdb
updateIP ()
{
	passwd= 
	while [ 1 ]; do
		addressId="$(mysql -Au root mi_jbossdb $passwd -Bse "select ADDRESS_ID from IPAddress where IP not in (select distinct IP from IPAddress join ServiceAppServers on IPAddress.ADDRESS_ID=ServiceAppServers.ADDRESS_ID);")"
		addressId_arr=($addressId)
		echo ${addressId_arr[*]}
		for element in ${addressId_arr[*]} 
		do
			echo "entered"
			mysql -Au root mi_jbossdb $passwd -Bse "insert ignore into ServiceAppServers values ('$element',8080,1,0);"
			mysql -Au root mi_jbossdb $passwd -Bse "insert ignore into ServiceAppServers values ('$element',8081,1,0);"
		done
		sleep 30
	done
}
updateIP 