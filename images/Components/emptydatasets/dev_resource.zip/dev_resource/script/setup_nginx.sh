#!/bin/bash

[ "$RESOURCE_DIR" == '' ] && export RESOURCE_DIR="$(pwd)"/..
. "$RESOURCE_DIR"/script/function_util.sh

NGINX_HOME=/usr/local/nginx
NGINX_BIN=$NGINX_HOME/sbin/nginx
NGINX_CONF=$NGINX_HOME/conf/nginx.conf

if [ -e "$NGINX_BIN" ]
then
        REWRITE_CONF="$RESOURCE_DIR"/nginx/rewrite.conf
        BUILD_NGINX_CONF="$RESOURCE_DIR"/nginx/nginx.conf

        sed -ie "s@include.*/rewrite.conf@include $REWRITE_CONF@g" $BUILD_NGINX_CONF
        dateTime=$(date +"%y_%m_%d_%T")
        sudo mv $NGINX_CONF "$NGINX_CONF"_"$dateTime"
        sudo cp $BUILD_NGINX_CONF $NGINX_CONF

        . "$RESOURCE_DIR"'/script/start_nginx.sh'

else
                echo "ERROR : Install NGINX refer  $RESOURCE_DIR   for installation information".
                exit 0
fi