#!/bin/bash

export RESOURCE_DIR="$(pwd)"

##################################BUILD SETUP SCRIPT START############################################### 

. setup.sh

##################################BUILD SETUP SCRIPT END###############################################


echo "Starting Platform setup"

# liveBuildHome="$PWD"'/AdventNetLive/Sas'
# BuilderBuildHome="$PWD"'/AdventNetBuilder/Sas'

# builder_zc_prop="$PWD"'/WEB-INF/conf/appcreator/zohocreator.properties'
sed -ie 's/isPlatformServer=.*/isPlatformServer=true/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties
sed -ie 's/platformliveurl=.*/platformliveurl=.localplatform.com/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties
sed -ie 's/creatorsuffixdomainname=.*/creatorsuffixdomainname=.csez.zohocorpin.com/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties
sed -ie 's/iamurl=http:/iamurl=https:/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties
sed -ie 's/integrationDreUrl=.*/integrationDreUrl=dre/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties

# live_zc_prop="$PWD"'/WEB-INF/conf/appcreator/zohocreator.properties'
sed -ie 's/isPlatformServer=.*/isPlatformServer=true/g' $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties
sed -ie 's/platformliveurl=.*/platformliveurl=.localplatform.com/g' $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties
sed -ie 's/creatorsuffixdomainname=.*/creatorsuffixdomainname=.csez.zohocorpin.com/g' $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties

# builder_zcdev_prop = "$PWD"'/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator_dev.properties'
# live_zcdev_prop = "$PWD"'/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator_dev.properties'

echo "newstoreLink=payments.csez.zohocorpin.com:8442" >> $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator_dev.properties
echo "newstoreLink=payments.csez.zohocorpin.com:8442" >> $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator_dev.properties

# struts_prop="$PWD"'/WEB-INF/classes/struts.properties'

sed -ie 's/struts.custom.i18n.resources=(.*)/struts.custom.i18n.resources=MarketplaceResources,MessageResources,AppMessageResources,DelugeMessageResources,LiveMessageResources,BuilderMessages,HelpOnboardMessages/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/classes/struts.properties

sed -i '' 's/tiles-appbuilder-4.xml/tiles-appbuilder-5.xml/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/web.xml
sed -i '' 's/struts-appbuilder-4.xml/struts-appbuilder-5.xml/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/classes/struts.xml
sed -i '' 's/isCreator5Server=false/isCreator5Server=true/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/appcreator/zohocreator.properties

sed -ie 's/com.zoho.zfs.server.url=http:/com.zoho.zfs.server.url=https:/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/zfsserver.properties
sed -ie 's/com.zoho.zfs.server.url=http:/com.zoho.zfs.server.url=https:/g' $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/zfsserver.properties
sed -ie 's/com.zoho.zfs.internal.server.url=http:/com.zoho.zfs.internal.server.url=https:/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/zfsserver.properties
sed -ie 's/com.zoho.zfs.internal.server.url=http:/com.zoho.zfs.internal.server.url=https:/g' $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/conf/zfsserver.properties
sed -ie 's/value="http:/value="https:/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/security-properties.xml
sed -ie 's/value="http:/value="https:/g' $RESOURCE_DIR/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/security-properties.xml

echo "Uncommenting iam.jsp in security xml..."
sed -ie 's/<!-- <url path="\/platform\/iam.jsp" trusted="true" operation-type="write"\/>-->/<url path="\/platform\/iam.jsp" trusted="true" operation-type="write"\/>/g' $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/security-platform.xml

echo "Removing roles from security filters..."
zc_prop=$RESOURCE_DIR'/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/security-admin.xml'
sed -ie 's/roles="[^ ]*"//g' $zc_prop

zc_prop=$RESOURCE_DIR'/AdventNetLive/Sas/tomcat/webapps/ROOT/WEB-INF/security.xml'
sed -ie 's/roles="[^ ]*"//g' $zc_prop

zc_prop=$RESOURCE_DIR'/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/security.xml'
sed -ie 's/roles="[^ ]*"//g' $zc_prop

echo "Changing dfs properties..."
sed -ie "s/NN1=.*/NN1=172.20.2.57:54310/g" $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/dfs.properties
echo "WRITABLE_GRID=true
NN1.WRITABLE=true" >> $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/dfs.properties

echo "Changing iam url in servicelogin.jsp..."
sed -ie "s~String iamServerName =.*~String iamServerName = \"https\:\/\/accounts.csez.zohocorpin.com\"\;~g" $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/service/live/jsp/servicelogin.jsp

echo "Adding entries in configuration.properties..."
echo "accounts.internal.domain=accounts.csez.zohocorpin.com
encryption.internal.domain=encryption.csez.zohocorpin.com
kms.client.id=ZN78Y6YEM56C20441WBEOWPU65WE4Y
kms.client.secret=5fae108bc2f252aac3892bae1a4aa1833801938a94
kms.file.redis.ip=172.20.100.66
kms.db.redis.ip=172.20.100.66
kms.redis.port=6379
kms.common.refreshtoken=1000.43e897ec781efbdca23b90ddabd94004.54db0e713754ab05ddaca9df07d028b8" >> $RESOURCE_DIR/AdventNetBuilder/Sas/tomcat/webapps/ROOT/WEB-INF/conf/configuration.properties


echo "Platform Setup completed"

