#!/bin/bash

ZIDE_ROOT=$1
RESOURCE_DIR=$ZIDE_ROOT'/dev_resource'
server_name=$2

cd $ZIDE_ROOT

find $ZIDE_ROOT -type f -name "*.sh" -exec chmod +x {} \;

export PATH=$PATH:$(dirname $(which mysql))

dir_name=$(basename "$PWD")

. $RESOURCE_DIR/script/function_util.sh

liveBuildHome=$ZIDE_ROOT'/AdventNetLive/Sas/'
BuilderBuildHome=$ZIDE_ROOT'/AdventNet/Sas/'


zide_prop=$ZIDE_ROOT'/../../'$dir_name"/.zide_resources/zide_properties.xml"


db_passwd="$(sed -n 's/.*ZIDE_DB_PASS\" value="\([^"]*\).*/\1/p' $zide_prop)"
db_username="$(sed -n 's/.*ZIDE_DB_USER\" value="\([^"]*\).*/\1/p' $zide_prop)"


. $RESOURCE_DIR/common_setup.sh no zide $RESOURCE_DIR $BuilderBuildHome $liveBuildHome $server_name $db_username $db_passwd
